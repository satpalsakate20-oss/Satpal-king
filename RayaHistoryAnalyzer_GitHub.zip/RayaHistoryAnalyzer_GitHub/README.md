# Raya History Analyzer — GitHub APK build

Upload this project to GitHub. GitHub Actions will build a debug APK whenever you push to `main`/`master`, or when you manually run **Build Android APK** from the Actions tab.

Phone steps:
1. Create a GitHub account.
2. Create a new repository.
3. Upload the project files.
4. Open **Actions**.
5. Select **Build Android APK**.
6. Tap **Run workflow**.
7. Open the completed workflow and download the `RayaHistoryAnalyzer-debug` artifact.
8. Extract it and install `app-debug.apk`.

Note: the standard Gradle Wrapper files (`gradlew`, `gradlew.bat`, `gradle/wrapper/*`) are not included in this generated package. Add them with Android Studio/Gradle before running the workflow if GitHub reports that `./gradlew` is missing.

This is a historical/statistical research app and does not guarantee prediction of future gambling results.
