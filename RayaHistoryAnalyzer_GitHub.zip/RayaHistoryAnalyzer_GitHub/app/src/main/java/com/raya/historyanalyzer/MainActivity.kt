package com.raya.historyanalyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Text("Raya History Analyzer", style = MaterialTheme.typography.headlineMedium)
                        Text("Historical Jodi/Panna statistics prototype")
                        Text("Next modules: CSV import, frequency analysis, arithmetic rules and back-testing.")
                        Text("Statistical candidates are experimental; past results do not reliably predict future gambling outcomes.")
                    }
                }
            }
        }
    }
}
